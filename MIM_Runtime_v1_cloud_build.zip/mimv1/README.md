# MIM Runtime v1

Fondasi launcher Android untuk MIM Universal Runtime.

Fitur:
- Launcher
- Game Profile
- Game Scanner
- Deteksi folder /Games
- Deteksi executable
- Status READY / DATA FOUND

v1 belum menjalankan executable PC. Tombol PLAY adalah placeholder untuk runtime engine v2.

Struktur:
 /Games/GTAV/GTA5.exe
 /Games/GTAIV/GTAIV.exe
 /Games/Skyrim/TESV.exe
