package com.mim.runtime.scanner

import android.content.Context
import android.os.Environment
import com.mim.runtime.data.GameProfiles
import com.mim.runtime.model.DetectedGame
import java.io.File

class GameScanner(private val context: Context) {
    private val gameRoot get() = File(Environment.getExternalStorageDirectory(), "Games")

    fun scan(): List<DetectedGame> {
        if (!gameRoot.isDirectory) return emptyList()
        return GameProfiles.defaults.mapNotNull { profile ->
            val dir = File(gameRoot, profile.folderName)
            if (!dir.isDirectory) return@mapNotNull null
            val exe = profile.executableHints.map { File(dir, it) }.firstOrNull(File::isFile)
            DetectedGame(profile, dir.absolutePath, exe?.absolutePath,
                if (exe != null) "READY" else "DATA FOUND")
        }
    }
}
