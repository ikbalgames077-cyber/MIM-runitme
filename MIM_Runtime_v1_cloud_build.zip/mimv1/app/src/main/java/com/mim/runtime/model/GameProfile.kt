package com.mim.runtime.model

data class GameProfile(
    val id: String,
    val name: String,
    val folderName: String,
    val executableHints: List<String>,
    val graphicsApi: String = "Auto",
    val cpuMode: String = "ARM64 Compatibility"
)
