package com.mim.runtime.data

import com.mim.runtime.model.GameProfile

object GameProfiles {
    val defaults = listOf(
        GameProfile("gta5", "Grand Theft Auto V", "GTAV", listOf("GTA5.exe", "PlayGTAV.exe")),
        GameProfile("gta4", "Grand Theft Auto IV", "GTAIV", listOf("GTAIV.exe", "LaunchGTAIV.exe")),
        GameProfile("skyrim", "The Elder Scrolls V: Skyrim", "Skyrim", listOf("TESV.exe", "SkyrimSE.exe"))
    )
}
