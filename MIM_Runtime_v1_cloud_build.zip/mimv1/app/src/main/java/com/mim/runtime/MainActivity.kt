package com.mim.runtime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mim.runtime.scanner.GameScanner

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Launcher(GameScanner(this)) } }
    }
}

@Composable
private fun Launcher(scanner: GameScanner) {
    var games by remember { mutableStateOf(scanner.scan()) }

    Scaffold(topBar = {
        TopAppBar(title = {
            Column {
                Text("MIM Runtime")
                Text("Universal Game Runtime • v1.0",
                    style = MaterialTheme.typography.labelSmall)
            }
        })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Button({ games = scanner.scan() }, Modifier.fillMaxWidth()) {
                Text("SCAN GAME")
            }
            Spacer(Modifier.height(16.dp))
            if (games.isEmpty()) {
                Text("Belum ada game ditemukan.\n\n" +
                    "Buat /Games/GTAV/, /Games/GTAIV/, atau /Games/Skyrim/.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(games) { game ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(game.profile.name,
                                    style = MaterialTheme.typography.titleMedium)
                                Text("Status: ${game.status}")
                                Text("Path: ${game.path}")
                                game.executable?.let { Text("Executable: ${it.substringAfterLast('/')}") }
                                Spacer(Modifier.height(10.dp))
                                Button({ /* runtime v2 */ }) { Text("PLAY") }
                            }
                        }
                    }
                }
            }
        }
    }
}
