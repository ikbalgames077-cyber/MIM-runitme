package com.mim.runtime.model

data class DetectedGame(
    val profile: GameProfile,
    val path: String,
    val executable: String?,
    val status: String
)
