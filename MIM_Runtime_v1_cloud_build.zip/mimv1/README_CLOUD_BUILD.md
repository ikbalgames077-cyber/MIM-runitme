# MIM Runtime v1 — Cloud Build

Project ini sudah disiapkan untuk build APK lewat GitHub Actions.

## Cara build

1. Buat repository GitHub baru, misalnya `MIM_Runtime_v1`.
2. Upload seluruh isi folder project ini ke repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build MIM Runtime APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai job selesai.
7. Buka hasil workflow tersebut dan cari bagian **Artifacts**.
8. Download **MIM_Runtime_v1_APK** lalu ekstrak ZIP-nya. Di dalamnya ada `app-debug.apk`.

Workflow juga otomatis berjalan ketika perubahan di-push ke branch `main`.

Catatan: v1 ini baru launcher + game scanner. Belum berisi engine/compatibility layer untuk menjalankan GTA V atau game PC.
